# Fantasy Bulldog Kennels - Nonprofit Website & Management System

## Project Overview

A comprehensive nonprofit website and management system for Fantasy Bulldog Kennels, focusing on providing housing, work opportunities, and reintegration pathways for formerly incarcerated individuals through bulldog rescue and care programs.

## Features

### Public Website
- **Home**: Hero section with mission overview, real-time donation counter, view counter
- **About**: Organization history, team, and impact statistics
- **Mission**: Detailed mission statement and core values
- **Programs**: Housing, employment, and animal care programs
- **Donation**: Multiple payment methods (Credit/Debit, PayPal, ACH, Crypto)
- **Volunteer**: Volunteer opportunities and application forms
- **Contact**: Contact information and location details
- **Legal**: Compliance information and donor promissory statement

### Admin Dashboard
- **Authentication**: Secure login system for staff
- **Donation Management**: Real-time donation tracking and reporting
- **Content Management**: Update program descriptions, announcements
- **Animal Profiles**: Manage bulldog rescue profiles and photos
- **Analytics**: View statistics and impact metrics
- **Thank You Letters**: Generate donor acknowledgment letters

### Real-Time Features
- **Donation Counter**: Updates in real-time as donations are processed
- **View Counter**: Tracks actual site visits
- **Live Analytics**: Current donation total and visitor statistics

## Technology Stack

### Frontend
- HTML5, CSS3, JavaScript (ES6+)
- Tailwind CSS for styling
- Responsive mobile-first design
- No external dependencies for core functionality

### Backend
- Node.js with Express.js
- SQLite database for data persistence
- JWT authentication for admin access
- RESTful API architecture

### Payment Processing
- Stripe for credit/debit cards
- PayPal integration
- ACH transfer support
- Cryptocurrency wallet addresses
- Real estate donation contracts

## File Structure

```
/mnt/okcomputer/output/
├── index.html              # Homepage
├── about.html              # About page
├── mission.html            # Mission statement
├── programs.html           # Programs overview
├── donate.html             # Donation page
├── volunteer.html          # Volunteer opportunities
├── contact.html            # Contact information
├── legal.html              # Legal compliance
├── admin.html              # Admin dashboard
├── main.js                 # Main JavaScript functionality
├── server.js               # Backend server
├── database.js             # Database operations
├── auth.js                 # Authentication system
├── resources/              # Images and assets
│   ├── hero_main.png       # Main hero image
│   ├── hero_programs.png   # Programs hero image
│   └── bulldogs/           # Bulldog photos
├── mission_statement.md    # Mission statement document
├── donor_promissory.md     # Donor commitment statement
└── README.md               # This file
```

## Installation & Setup

### Prerequisites
- Node.js (v14 or higher)
- npm or yarn package manager
- Modern web browser

### Backend Setup
1. Install dependencies:
   ```bash
   npm install express sqlite3 jsonwebtoken bcryptjs cors
   ```

2. Start the server:
   ```bash
   node server.js
   ```

3. The server runs on http://localhost:3000

### Frontend Setup
1. All HTML files are static and ready to serve
2. Open index.html in a browser or serve via HTTP server
3. For development: `python -m http.server 8000`

### Admin Account Setup
1. Default admin credentials (change immediately):
   - Username: admin
   - Password: admin123

2. Change password after first login

## API Endpoints

### Public Endpoints
- `GET /api/stats` - Get donation total and view count
- `POST /api/contact` - Submit contact form
- `GET /api/bulldogs` - Get available bulldogs list

### Admin Endpoints
- `POST /api/admin/login` - Admin authentication
- `GET /api/admin/dashboard` - Admin dashboard data
- `POST /api/admin/update-content` - Update website content
- `GET /api/admin/donations` - Get donation reports
- `POST /api/admin/generate-letter` - Generate thank you letters

### Donation Processing
- `POST /api/donate/stripe` - Process Stripe payment
- `POST /api/donate/paypal` - Process PayPal payment
- `POST /api/donate/crypto` - Record crypto donation
- `POST /api/donate/property` - Process property donation

## Database Schema

### Tables
1. **donations** - Track all donations
2. **views** - Track site visits
3. **admins** - Admin user accounts
4. **bulldogs** - Animal profiles
5. **volunteers** - Volunteer applications
6. **content** - Dynamic website content

## Security Features
- JWT token authentication
- Password hashing with bcrypt
- HTTPS enforcement
- Input validation and sanitization
- Rate limiting on API endpoints
- CORS protection

## Deployment Options

### Option 1: Traditional Hosting
- Upload files to web server
- Run Node.js backend on server
- Configure SSL certificate
- Set up database

### Option 2: Cloud Platforms
- **Netlify**: Frontend hosting with serverless functions
- **Vercel**: Full-stack deployment
- **Heroku**: Backend hosting with database
- **AWS**: EC2 for backend, S3 for frontend

### Option 3: VPS/Dedicated Server
- Install Node.js and dependencies
- Configure reverse proxy (nginx)
- Set up SSL with Let's Encrypt
- Configure firewall and security

## Legal Compliance
- 501(c)(3) nonprofit language included
- Donor privacy protection
- Financial transparency requirements
- IRS compliance documentation
- State charity registration ready

## Maintenance
- Regular security updates
- Database backups
- Performance monitoring
- Content updates via admin panel
- Donation reconciliation

## Support
For technical support or questions about the system, contact the development team through the admin dashboard or technical documentation.