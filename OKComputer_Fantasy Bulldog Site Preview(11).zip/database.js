const sqlite3 = require('sqlite3').verbose();
const fs = require('fs');
const path = require('path');

class Database {
  constructor() {
    this.dbPath = path.join(__dirname, 'fantasy_bulldog_kennels.db');
    this.db = null;
    this.init();
  }

  init() {
    // Create database if it doesn't exist
    this.db = new sqlite3.Database(this.dbPath, (err) => {
      if (err) {
        console.error('Error opening database:', err);
      } else {
        console.log('Database connected successfully');
        this.createTables();
        this.seedData();
      }
    });
  }

  createTables() {
    // Donations table
    this.db.run(`
      CREATE TABLE IF NOT EXISTS donations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        amount REAL NOT NULL,
        donor_name TEXT NOT NULL,
        donor_email TEXT NOT NULL,
        method TEXT NOT NULL,
        message TEXT,
        status TEXT DEFAULT 'pending',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        completed_at DATETIME,
        receipt_sent BOOLEAN DEFAULT FALSE
      )
    `);

    // Views table
    this.db.run(`
      CREATE TABLE IF NOT EXISTS views (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ip_address TEXT,
        user_agent TEXT,
        page TEXT,
        viewed_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Admins table
    this.db.run(`
      CREATE TABLE IF NOT EXISTS admins (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        name TEXT NOT NULL,
        email TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        last_login DATETIME
      )
    `);

    // Bulldogs table
    this.db.run(`
      CREATE TABLE IF NOT EXISTS bulldogs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        breed TEXT NOT NULL,
        age INTEGER,
        description TEXT NOT NULL,
        medical_status TEXT,
        photo_url TEXT,
        status TEXT DEFAULT 'available',
        intake_date DATETIME DEFAULT CURRENT_TIMESTAMP,
        adoption_date DATETIME
      )
    `);

    // Volunteers table
    this.db.run(`
      CREATE TABLE IF NOT EXISTS volunteers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT NOT NULL,
        phone TEXT NOT NULL,
        experience TEXT,
        availability TEXT,
        interests TEXT,
        status TEXT DEFAULT 'pending',
        applied_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Contact messages table
    this.db.run(`
      CREATE TABLE IF NOT EXISTS contact_messages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT NOT NULL,
        subject TEXT,
        message TEXT NOT NULL,
        status TEXT DEFAULT 'new',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Content table for dynamic content
    this.db.run(`
      CREATE TABLE IF NOT EXISTS content (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        section TEXT UNIQUE NOT NULL,
        content TEXT,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Site stats table
    this.db.run(`
      CREATE TABLE IF NOT EXISTS site_stats (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        total_donations REAL DEFAULT 0,
        total_views INTEGER DEFAULT 0,
        last_updated DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `);
  }

  seedData() {
    // Initialize site stats if empty
    this.db.get('SELECT COUNT(*) as count FROM site_stats', (err, row) => {
      if (err) {
        console.error('Error checking site_stats:', err);
        return;
      }
      
      if (row.count === 0) {
        this.db.run('INSERT INTO site_stats (total_donations, total_views) VALUES (0, 0)');
        console.log('Initialized site stats');
      }
    });

    // Add default content sections
    const defaultContent = [
      { section: 'hero_title', content: 'Second Chances for People & Bulldogs' },
      { section: 'hero_subtitle', content: 'Transforming lives through compassionate animal care and meaningful employment' },
      { section: 'about_text', content: 'Fantasy Bulldog Kennels is dedicated to breaking the cycle of recidivism by creating transformative pathways for formerly incarcerated individuals through bulldog rescue and care.' },
      { section: 'programs_housing', content: 'Safe, supportive housing for program participants during their transition period.' },
      { section: 'programs_employment', content: 'Paid training in animal care, facility maintenance, customer service, and administrative support.' },
      { section: 'programs_animal_care', content: 'Comprehensive veterinary care, behavioral training, and rehabilitation for rescued bulldogs.' }
    ];

    defaultContent.forEach(({ section, content }) => {
      this.db.get('SELECT COUNT(*) as count FROM content WHERE section = ?', [section], (err, row) => {
        if (err) {
          console.error('Error checking content:', err);
          return;
        }
        
        if (row.count === 0) {
          this.db.run('INSERT INTO content (section, content) VALUES (?, ?)', [section, content]);
          console.log(`Added default content for ${section}`);
        }
      });
    });

    // Add sample bulldogs
    this.db.get('SELECT COUNT(*) as count FROM bulldogs', (err, row) => {
      if (err) {
        console.error('Error checking bulldogs:', err);
        return;
      }
      
      if (row.count === 0) {
        const sampleBulldogs = [
          {
            name: 'Brutus',
            breed: 'English Bulldog',
            age: 4,
            description: 'Gentle giant who loves cuddles and short walks. Great with children and other dogs.',
            medical_status: 'Healthy, neutered, up-to-date on vaccinations',
            photo_url: 'https://kimi-web-img.moonshot.cn/img/static.boredpanda.com/532fa3f67a61b1fcfb12a2892949dc4dbae8a718.jpg'
          },
          {
            name: 'Bella',
            breed: 'French Bulldog',
            age: 2,
            description: 'Playful and energetic little lady who loves to play fetch and snuggle.',
            medical_status: 'Healthy, spayed, microchipped',
            photo_url: 'https://kimi-web-img.moonshot.cn/img/hips.hearstapps.com/4870e93256bc333103c75f7726297c106363c3d7.jpg'
          },
          {
            name: 'Tank',
            breed: 'Pocket Bully',
            age: 3,
            description: 'Strong but sweet companion who needs an experienced owner and lots of love.',
            medical_status: 'Undergoing behavioral rehabilitation, making great progress',
            photo_url: 'https://kimi-web-img.moonshot.cn/img/static.pupperish.com/9df3ddff7516775b84c44029b0a99bf76694cc4b.jpg'
          }
        ];

        sampleBulldogs.forEach(bulldog => {
          this.db.run(`
            INSERT INTO bulldogs (name, breed, age, description, medical_status, photo_url)
            VALUES (?, ?, ?, ?, ?, ?)
          `, [bulldog.name, bulldog.breed, bulldog.age, bulldog.description, bulldog.medical_status, bulldog.photo_url]);
        });
        
        console.log('Added sample bulldogs');
      }
    });
  }

  // Statistics methods
  async getStats() {
    return new Promise((resolve, reject) => {
      this.db.get('SELECT * FROM site_stats', (err, row) => {
        if (err) {
          reject(err);
        } else {
          resolve(row || { total_donations: 0, total_views: 0 });
        }
      });
    });
  }

  async recordView() {
    return new Promise((resolve, reject) => {
      this.db.run('UPDATE site_stats SET total_views = total_views + 1, last_updated = CURRENT_TIMESTAMP', (err) => {
        if (err) {
          reject(err);
        } else {
          resolve();
        }
      });
    });
  }

  async updateDonationTotal(amount) {
    return new Promise((resolve, reject) => {
      this.db.run('UPDATE site_stats SET total_donations = total_donations + ?, last_updated = CURRENT_TIMESTAMP', [amount], (err) => {
        if (err) {
          reject(err);
        } else {
          resolve();
        }
      });
    });
  }

  // Donation methods
  async saveDonation(donationData) {
    return new Promise((resolve, reject) => {
      const {
        amount, donor_name, donor_email, method, message, status, completed_at
      } = donationData;
      
      this.db.run(`
        INSERT INTO donations (amount, donor_name, donor_email, method, message, status, completed_at)
        VALUES (?, ?, ?, ?, ?, ?, ?)
      `, [amount, donor_name, donor_email, method, message, status, completed_at], function(err) {
        if (err) {
          reject(err);
        } else {
          resolve(this.lastID);
        }
      });
    });
  }

  async getDonations() {
    return new Promise((resolve, reject) => {
      this.db.all('SELECT * FROM donations ORDER BY created_at DESC', (err, rows) => {
        if (err) {
          reject(err);
        } else {
          resolve(rows);
        }
      });
    });
  }

  async getDonationById(id) {
    return new Promise((resolve, reject) => {
      this.db.get('SELECT * FROM donations WHERE id = ?', [id], (err, row) => {
        if (err) {
          reject(err);
        } else {
          resolve(row);
        }
      });
    });
  }

  // Admin methods
  async getAdminByUsername(username) {
    return new Promise((resolve, reject) => {
      this.db.get('SELECT * FROM admins WHERE username = ?', [username], (err, row) => {
        if (err) {
          reject(err);
        } else {
          resolve(row);
        }
      });
    });
  }

  async createAdmin(adminData) {
    return new Promise((resolve, reject) => {
      const { username, password_hash, name, email } = adminData;
      
      this.db.run(`
        INSERT INTO admins (username, password_hash, name, email)
        VALUES (?, ?, ?, ?)
      `, [username, password_hash, name, email], function(err) {
        if (err) {
          reject(err);
        } else {
          resolve(this.lastID);
        }
      });
    });
  }

  // Bulldog methods
  async getAvailableBulldogs() {
    return new Promise((resolve, reject) => {
      this.db.all('SELECT * FROM bulldogs WHERE status = ? ORDER BY intake_date DESC', ['available'], (err, rows) => {
        if (err) {
          reject(err);
        } else {
          resolve(rows);
        }
      });
    });
  }

  async addBulldog(bulldogData) {
    return new Promise((resolve, reject) => {
      const { name, breed, age, description, medical_status, photo_url } = bulldogData;
      
      this.db.run(`
        INSERT INTO bulldogs (name, breed, age, description, medical_status, photo_url)
        VALUES (?, ?, ?, ?, ?, ?)
      `, [name, breed, age, description, medical_status, photo_url], function(err) {
        if (err) {
          reject(err);
        } else {
          resolve(this.lastID);
        }
      });
    });
  }

  // Content methods
  async getContent(section) {
    return new Promise((resolve, reject) => {
      this.db.get('SELECT content FROM content WHERE section = ?', [section], (err, row) => {
        if (err) {
          reject(err);
        } else {
          resolve(row ? row.content : '');
        }
      });
    });
  }

  async updateContent(section, content) {
    return new Promise((resolve, reject) => {
      this.db.run(`
        INSERT OR REPLACE INTO content (section, content, updated_at)
        VALUES (?, ?, CURRENT_TIMESTAMP)
      `, [section, content], (err) => {
        if (err) {
          reject(err);
        } else {
          resolve();
        }
      });
    });
  }

  // Volunteer methods
  async saveVolunteerApplication(applicationData) {
    return new Promise((resolve, reject) => {
      const { name, email, phone, experience, availability, interests } = applicationData;
      
      this.db.run(`
        INSERT INTO volunteers (name, email, phone, experience, availability, interests)
        VALUES (?, ?, ?, ?, ?, ?)
      `, [name, email, phone, experience, availability, interests], function(err) {
        if (err) {
          reject(err);
        } else {
          resolve(this.lastID);
        }
      });
    });
  }

  // Contact methods
  async saveContactMessage(messageData) {
    return new Promise((resolve, reject) => {
      const { name, email, subject, message } = messageData;
      
      this.db.run(`
        INSERT INTO contact_messages (name, email, subject, message)
        VALUES (?, ?, ?, ?)
      `, [name, email, subject, message], function(err) {
        if (err) {
          reject(err);
        } else {
          resolve(this.lastID);
        }
      });
    });
  }

  // Dashboard data
  async getDashboardData() {
    return new Promise((resolve, reject) => {
      const queries = [
        'SELECT COUNT(*) as total_donations FROM donations WHERE status = "completed"',
        'SELECT SUM(amount) as total_amount FROM donations WHERE status = "completed"',
        'SELECT COUNT(*) as total_views FROM views',
        'SELECT COUNT(*) as total_bulldogs FROM bulldogs',
        'SELECT COUNT(*) as available_bulldogs FROM bulldogs WHERE status = "available"',
        'SELECT COUNT(*) as pending_volunteers FROM volunteers WHERE status = "pending"',
        'SELECT COUNT(*) as new_messages FROM contact_messages WHERE status = "new"',
        'SELECT * FROM donations WHERE status = "completed" ORDER BY completed_at DESC LIMIT 5'
      ];

      let results = {};
      let completed = 0;

      queries.forEach((query, index) => {
        this.db.get(query, (err, row) => {
          if (err) {
            reject(err);
            return;
          }

          switch(index) {
            case 0: results.donation_count = row.total_donations; break;
            case 1: results.total_donated = row.total_amount || 0; break;
            case 2: results.total_views = row.total_views; break;
            case 3: results.total_bulldogs = row.total_bulldogs; break;
            case 4: results.available_bulldogs = row.available_bulldogs; break;
            case 5: results.pending_volunteers = row.pending_volunteers; break;
            case 6: results.new_messages = row.new_messages; break;
            case 7: results.recent_donations = [row]; break;
          }

          completed++;
          if (completed === queries.length) {
            resolve(results);
          }
        });
      });
    });
  }

  // Close database connection
  close() {
    return new Promise((resolve) => {
      this.db.close((err) => {
        if (err) {
          console.error('Error closing database:', err);
        }
        resolve();
      });
    });
  }
}

module.exports = Database;