// Admin Dashboard JavaScript
class AdminDashboard {
    constructor() {
        this.apiBase = window.location.origin;
        this.token = localStorage.getItem('admin_token');
        this.currentSection = 'dashboard';
        this.init();
    }

    init() {
        if (!this.token) {
            window.location.href = 'login.html';
            return;
        }

        this.setupEventListeners();
        this.loadDashboard();
        this.loadAdminInfo();
    }

    setupEventListeners() {
        // Navigation
        document.querySelectorAll('.sidebar-nav a').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const section = link.dataset.section;
                this.switchSection(section);
            });
        });

        // Logout
        document.getElementById('logout-btn').addEventListener('click', () => {
            this.logout();
        });

        // Add Bulldog Modal
        document.getElementById('add-bulldog-btn').addEventListener('click', () => {
            this.openModal('add-bulldog-modal');
        });

        // Add Bulldog Form
        document.getElementById('add-bulldog-form').addEventListener('submit', (e) => {
            e.preventDefault();
            this.addBulldog();
        });

        // Generate Report
        document.getElementById('generate-report-btn').addEventListener('click', () => {
            this.generateReport();
        });
    }

    async loadAdminInfo() {
        try {
            const user = JSON.parse(localStorage.getItem('admin_user') || '{}');
            document.getElementById('admin-name').textContent = user.name || 'Admin';
        } catch (error) {
            console.error('Error loading admin info:', error);
        }
    }

    async switchSection(section) {
        // Update navigation
        document.querySelectorAll('.sidebar-nav a').forEach(link => {
            link.classList.remove('active');
        });
        document.querySelector(`[data-section="${section}"]`).classList.add('active');

        // Hide all sections
        document.querySelectorAll('.content-area').forEach(area => {
            area.classList.remove('active');
        });

        // Show selected section
        document.getElementById(`${section}-section`).classList.add('active');

        this.currentSection = section;

        // Load section data
        switch (section) {
            case 'dashboard':
                await this.loadDashboard();
                break;
            case 'donations':
                await this.loadDonations();
                break;
            case 'content':
                await this.loadContent();
                break;
            case 'bulldogs':
                await this.loadBulldogs();
                break;
            case 'volunteers':
                await this.loadVolunteers();
                break;
            case 'messages':
                await this.loadMessages();
                break;
        }
    }

    async loadDashboard() {
        try {
            const response = await fetch(`${this.apiBase}/api/admin/dashboard`, {
                headers: { 'Authorization': `Bearer ${this.token}` }
            });

            if (response.ok) {
                const data = await response.json();
                this.updateDashboardStats(data);
                this.updateRecentActivity(data);
            } else if (response.status === 401) {
                this.logout();
            }
        } catch (error) {
            console.error('Error loading dashboard:', error);
        }
    }

    updateDashboardStats(data) {
        document.getElementById('total-donations').textContent = `$${data.total_donated.toFixed(2)}`;
        document.getElementById('total-views').textContent = data.total_views.toLocaleString();
        document.getElementById('total-bulldogs').textContent = data.total_bulldogs;
        document.getElementById('pending-volunteers').textContent = data.pending_volunteers;
    }

    updateRecentActivity(data) {
        // Recent Donations
        const donationsContainer = document.getElementById('recent-donations');
        if (data.recent_donations && data.recent_donations.length > 0) {
            donationsContainer.innerHTML = data.recent_donations.map(donation => `
                <div class="flex justify-between items-center py-3 border-b border-gray-200 last:border-b-0">
                    <div>
                        <p class="font-medium">${donation.donor_name}</p>
                        <p class="text-sm text-gray-500">$${donation.amount.toFixed(2)}</p>
                    </div>
                    <div class="text-right">
                        <p class="text-sm text-gray-500">${new Date(donation.created_at).toLocaleDateString()}</p>
                        <span class="status-badge status-completed">Completed</span>
                    </div>
                </div>
            `).join('');
        } else {
            donationsContainer.innerHTML = '<p class="text-gray-500 text-center py-4">No recent donations</p>';
        }

        // Recent Messages
        const messagesContainer = document.getElementById('recent-messages');
        if (data.new_messages && data.new_messages > 0) {
            messagesContainer.innerHTML = `
                <div class="text-center py-4">
                    <p class="text-lg font-semibold text-blue-600">${data.new_messages} New Messages</p>
                    <p class="text-gray-600 mt-2">Check the Messages section to review</p>
                    <button class="btn-primary mt-4" onclick="adminDashboard.switchSection('messages')">View Messages</button>
                </div>
            `;
        } else {
            messagesContainer.innerHTML = '<p class="text-gray-500 text-center py-4">No new messages</p>';
        }
    }

    async loadDonations() {
        try {
            const response = await fetch(`${this.apiBase}/api/admin/donations`, {
                headers: { 'Authorization': `Bearer ${this.token}` }
            });

            if (response.ok) {
                const donations = await response.json();
                this.updateDonationsTable(donations);
            }
        } catch (error) {
            console.error('Error loading donations:', error);
        }
    }

    updateDonationsTable(donations) {
        const tbody = document.getElementById('donations-table-body');
        
        if (donations.length === 0) {
            tbody.innerHTML = '<tr><td colspan="6" class="text-center text-gray-500 py-8">No donations found</td></tr>';
            return;
        }

        tbody.innerHTML = donations.map(donation => `
            <tr>
                <td>${new Date(donation.created_at).toLocaleDateString()}</td>
                <td>${donation.donor_name}</td>
                <td>$${donation.amount.toFixed(2)}</td>
                <td>${donation.method}</td>
                <td><span class="status-badge status-${donation.status}">${donation.status}</span></td>
                <td>
                    <button class="btn-primary text-sm px-3 py-1" onclick="adminDashboard.generateThankYouLetter(${donation.id})">
                        Generate Letter
                    </button>
                </td>
            </tr>
        `).join('');
    }

    async loadContent() {
        try {
            // Load current content values
            const sections = ['hero_title', 'hero_subtitle', 'about_text', 'programs_housing', 'programs_employment'];
            
            for (const section of sections) {
                const response = await fetch(`${this.apiBase}/api/admin/content`, {
                    method: 'POST',
                    headers: { 
                        'Authorization': `Bearer ${this.token}`,
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ section })
                });

                if (response.ok) {
                    const content = await response.json();
                    const element = document.getElementById(section.replace('_', '-'));
                    if (element) {
                        element.value = content.content || '';
                    }
                }
            }
        } catch (error) {
            console.error('Error loading content:', error);
        }
    }

    async loadBulldogs() {
        try {
            const response = await fetch(`${this.apiBase}/api/bulldogs`);
            
            if (response.ok) {
                const bulldogs = await response.json();
                this.updateBulldogsTable(bulldogs);
            }
        } catch (error) {
            console.error('Error loading bulldogs:', error);
        }
    }

    updateBulldogsTable(bulldogs) {
        const tbody = document.getElementById('bulldogs-table-body');
        
        if (bulldogs.length === 0) {
            tbody.innerHTML = '<tr><td colspan="6" class="text-center text-gray-500 py-8">No bulldogs found</td></tr>';
            return;
        }

        tbody.innerHTML = bulldogs.map(bulldog => `
            <tr>
                <td>${bulldog.name}</td>
                <td>${bulldog.breed}</td>
                <td>${bulldog.age || 'Unknown'}</td>
                <td><span class="status-badge status-${bulldog.status}">${bulldog.status}</span></td>
                <td>${new Date(bulldog.intake_date).toLocaleDateString()}</td>
                <td>
                    <button class="btn-secondary text-sm px-3 py-1 mr-2" onclick="adminDashboard.editBulldog(${bulldog.id})">
                        Edit
                    </button>
                    <button class="btn-primary text-sm px-3 py-1" onclick="adminDashboard.deleteBulldog(${bulldog.id})">
                        Delete
                    </button>
                </td>
            </tr>
        `).join('');
    }

    async loadVolunteers() {
        try {
            const response = await fetch(`${this.apiBase}/api/admin/volunteers`, {
                headers: { 'Authorization': `Bearer ${this.token}` }
            });

            if (response.ok) {
                const volunteers = await response.json();
                this.updateVolunteersTable(volunteers);
            }
        } catch (error) {
            console.error('Error loading volunteers:', error);
        }
    }

    updateVolunteersTable(volunteers) {
        const tbody = document.getElementById('volunteers-table-body');
        
        if (volunteers.length === 0) {
            tbody.innerHTML = '<tr><td colspan="7" class="text-center text-gray-500 py-8">No volunteer applications found</td></tr>';
            return;
        }

        tbody.innerHTML = volunteers.map(volunteer => `
            <tr>
                <td>${volunteer.name}</td>
                <td>${volunteer.email}</td>
                <td>${volunteer.phone}</td>
                <td>${volunteer.interests || 'Not specified'}</td>
                <td>${new Date(volunteer.applied_at).toLocaleDateString()}</td>
                <td><span class="status-badge status-${volunteer.status}">${volunteer.status}</span></td>
                <td>
                    <button class="btn-primary text-sm px-3 py-1" onclick="adminDashboard.reviewVolunteer(${volunteer.id})">
                        Review
                    </button>
                </td>
            </tr>
        `).join('');
    }

    async loadMessages() {
        try {
            // This would need to be implemented in the backend
            const response = await fetch(`${this.apiBase}/api/admin/messages`, {
                headers: { 'Authorization': `Bearer ${this.token}` }
            });

            if (response.ok) {
                const messages = await response.json();
                this.updateMessagesTable(messages);
            }
        } catch (error) {
            console.error('Error loading messages:', error);
            // Show empty state for now
            document.getElementById('messages-table-body').innerHTML = '<tr><td colspan="6" class="text-center text-gray-500 py-8">Messages feature coming soon</td></tr>';
        }
    }

    updateMessagesTable(messages) {
        const tbody = document.getElementById('messages-table-body');
        
        if (messages.length === 0) {
            tbody.innerHTML = '<tr><td colspan="6" class="text-center text-gray-500 py-8">No messages found</td></tr>';
            return;
        }

        tbody.innerHTML = messages.map(message => `
            <tr>
                <td>${message.name}</td>
                <td>${message.email}</td>
                <td>${message.subject}</td>
                <td>${new Date(message.created_at).toLocaleDateString()}</td>
                <td><span class="status-badge status-${message.status}">${message.status}</span></td>
                <td>
                    <button class="btn-primary text-sm px-3 py-1" onclick="adminDashboard.viewMessage(${message.id})">
                        View
                    </button>
                </td>
            </tr>
        `).join('');
    }

    async updateContent(section) {
        try {
            let content = '';
            
            switch (section) {
                case 'hero':
                    content = {
                        hero_title: document.getElementById('hero-title').value,
                        hero_subtitle: document.getElementById('hero-subtitle').value
                    };
                    break;
                case 'about':
                    content = {
                        about_text: document.getElementById('about-text').value
                    };
                    break;
                case 'programs':
                    content = {
                        programs_housing: document.getElementById('programs-housing').value,
                        programs_employment: document.getElementById('programs-employment').value
                    };
                    break;
            }

            for (const [key, value] of Object.entries(content)) {
                const response = await fetch(`${this.apiBase}/api/admin/content`, {
                    method: 'POST',
                    headers: { 
                        'Authorization': `Bearer ${this.token}`,
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ section: key, content: value })
                });

                if (!response.ok) {
                    throw new Error('Failed to update content');
                }
            }

            this.showMessage('Content updated successfully!', 'success');
        } catch (error) {
            console.error('Error updating content:', error);
            this.showMessage('Failed to update content', 'error');
        }
    }

    async updateStats() {
        try {
            const donationTotal = parseFloat(document.getElementById('donation-total').value) || 0;
            const siteViews = parseInt(document.getElementById('site-views').value) || 0;

            // Update donation total
            await fetch(`${this.apiBase}/api/admin/stats`, {
                method: 'POST',
                headers: { 
                    'Authorization': `Bearer ${this.token}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ total_donations: donationTotal, total_views: siteViews })
            });

            this.showMessage('Statistics updated successfully!', 'success');
        } catch (error) {
            console.error('Error updating stats:', error);
            this.showMessage('Failed to update statistics', 'error');
        }
    }

    async addBulldog() {
        try {
            const form = document.getElementById('add-bulldog-form');
            const formData = new FormData(form);
            
            const bulldogData = {
                name: formData.get('name'),
                breed: formData.get('breed'),
                age: parseInt(formData.get('age')) || null,
                description: formData.get('description'),
                medical_status: formData.get('medical_status') || '',
                photo_url: formData.get('photo_url') || '',
                status: formData.get('status') || 'available'
            };

            const response = await fetch(`${this.apiBase}/api/admin/bulldogs`, {
                method: 'POST',
                headers: { 
                    'Authorization': `Bearer ${this.token}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(bulldogData)
            });

            if (response.ok) {
                this.showMessage('Bulldog added successfully!', 'success');
                this.closeModal('add-bulldog-modal');
                form.reset();
                this.loadBulldogs();
            } else {
                this.showMessage('Failed to add bulldog', 'error');
            }
        } catch (error) {
            console.error('Error adding bulldog:', error);
            this.showMessage('Failed to add bulldog', 'error');
        }
    }

    async generateThankYouLetter(donationId) {
        try {
            const response = await fetch(`${this.apiBase}/api/admin/generate-letter`, {
                method: 'POST',
                headers: { 
                    'Authorization': `Bearer ${this.token}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ donation_id: donationId })
            });

            if (response.ok) {
                const data = await response.json();
                document.getElementById('letter-content').textContent = data.letter;
                this.openModal('letter-modal');
            }
        } catch (error) {
            console.error('Error generating letter:', error);
            this.showMessage('Failed to generate letter', 'error');
        }
    }

    generateReport() {
        // Placeholder for report generation
        this.showMessage('Report generation feature coming soon!', 'info');
    }

    editBulldog(id) {
        this.showMessage('Edit bulldog feature coming soon!', 'info');
    }

    deleteBulldog(id) {
        if (confirm('Are you sure you want to delete this bulldog?')) {
            this.showMessage('Delete bulldog feature coming soon!', 'info');
        }
    }

    reviewVolunteer(id) {
        this.showMessage('Volunteer review feature coming soon!', 'info');
    }

    viewMessage(id) {
        this.showMessage('Message view feature coming soon!', 'info');
    }

    openModal(modalId) {
        document.getElementById(modalId).classList.add('active');
    }

    closeModal(modalId) {
        document.getElementById(modalId).classList.remove('active');
    }

    copyLetter() {
        const letterContent = document.getElementById('letter-content').textContent;
        navigator.clipboard.writeText(letterContent).then(() => {
            this.showMessage('Letter copied to clipboard!', 'success');
        });
    }

    downloadLetter() {
        this.showMessage('PDF download feature coming soon!', 'info');
    }

    logout() {
        localStorage.removeItem('admin_token');
        localStorage.removeItem('admin_user');
        window.location.href = 'index.html';
    }

    showMessage(message, type) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `message message-${type}`;
        messageDiv.textContent = message;
        
        messageDiv.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 1rem 1.5rem;
            border-radius: 8px;
            color: white;
            font-weight: 500;
            z-index: 10000;
            max-width: 400px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            background: ${type === 'success' ? '#059669' : type === 'error' ? '#dc2626' : '#3b82f6'};
        `;
        
        document.body.appendChild(messageDiv);
        
        setTimeout(() => {
            messageDiv.style.transform = 'translateX(100%)';
            messageDiv.style.opacity = '0';
            setTimeout(() => messageDiv.remove(), 300);
        }, 5000);
    }
}

// Initialize admin dashboard
const adminDashboard = new AdminDashboard();

// Global functions for onclick handlers
window.adminDashboard = adminDashboard;