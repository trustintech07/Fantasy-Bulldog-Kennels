const express = require('express');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const path = require('path');
const Database = require('./database');

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key-change-in-production';

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname)));

// Initialize database
const db = new Database();

// Authentication middleware
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  
  if (!token) {
    return res.status(401).json({ error: 'Access token required' });
  }
  
  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({ error: 'Invalid token' });
    }
    req.user = user;
    next();
  });
};

// Public API endpoints

// Get site statistics
app.get('/api/stats', async (req, res) => {
  try {
    const stats = await db.getStats();
    res.json(stats);
  } catch (error) {
    console.error('Error fetching stats:', error);
    res.status(500).json({ error: 'Failed to fetch statistics' });
  }
});

// Record page view
app.post('/api/view', async (req, res) => {
  try {
    await db.recordView();
    res.json({ success: true });
  } catch (error) {
    console.error('Error recording view:', error);
    res.status(500).json({ error: 'Failed to record view' });
  }
});

// Get available bulldogs
app.get('/api/bulldogs', async (req, res) => {
  try {
    const bulldogs = await db.getAvailableBulldogs();
    res.json(bulldogs);
  } catch (error) {
    console.error('Error fetching bulldogs:', error);
    res.status(500).json({ error: 'Failed to fetch bulldogs' });
  }
});

// Contact form submission
app.post('/api/contact', async (req, res) => {
  try {
    const { name, email, message, subject } = req.body;
    
    // Validate input
    if (!name || !email || !message) {
      return res.status(400).json({ error: 'All fields are required' });
    }
    
    // Save contact message
    await db.saveContactMessage({ name, email, subject, message });
    
    res.json({ success: true, message: 'Message sent successfully' });
  } catch (error) {
    console.error('Error saving contact message:', error);
    res.status(500).json({ error: 'Failed to send message' });
  }
});

// Volunteer application
app.post('/api/volunteer', async (req, res) => {
  try {
    const { name, email, phone, experience, availability, interests } = req.body;
    
    // Validate input
    if (!name || !email || !phone) {
      return res.status(400).json({ error: 'Required fields missing' });
    }
    
    // Save volunteer application
    await db.saveVolunteerApplication({ 
      name, email, phone, experience, availability, interests 
    });
    
    res.json({ success: true, message: 'Application submitted successfully' });
  } catch (error) {
    console.error('Error saving volunteer application:', error);
    res.status(500).json({ error: 'Failed to submit application' });
  }
});

// Admin authentication
app.post('/api/admin/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    
    // Validate input
    if (!username || !password) {
      return res.status(400).json({ error: 'Username and password required' });
    }
    
    // Get admin user
    const admin = await db.getAdminByUsername(username);
    if (!admin) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }
    
    // Verify password
    const isValid = await bcrypt.compare(password, admin.password_hash);
    if (!isValid) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }
    
    // Generate JWT token
    const token = jwt.sign(
      { id: admin.id, username: admin.username },
      JWT_SECRET,
      { expiresIn: '8h' }
    );
    
    res.json({ 
      token, 
      user: { id: admin.id, username: admin.username, name: admin.name }
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ error: 'Login failed' });
  }
});

// Admin dashboard data
app.get('/api/admin/dashboard', authenticateToken, async (req, res) => {
  try {
    const dashboardData = await db.getDashboardData();
    res.json(dashboardData);
  } catch (error) {
    console.error('Error fetching dashboard data:', error);
    res.status(500).json({ error: 'Failed to fetch dashboard data' });
  }
});

// Get donations
app.get('/api/admin/donations', authenticateToken, async (req, res) => {
  try {
    const donations = await db.getDonations();
    res.json(donations);
  } catch (error) {
    console.error('Error fetching donations:', error);
    res.status(500).json({ error: 'Failed to fetch donations' });
  }
});

// Process donation
app.post('/api/donate', async (req, res) => {
  try {
    const { amount, donor_name, donor_email, method, message } = req.body;
    
    // Validate input
    if (!amount || amount <= 0) {
      return res.status(400).json({ error: 'Invalid donation amount' });
    }
    
    if (!donor_name || !donor_email) {
      return res.status(400).json({ error: 'Donor information required' });
    }
    
    // Process donation based on method
    let donationData = {
      amount,
      donor_name,
      donor_email,
      method: method || 'unknown',
      message: message || '',
      status: 'pending'
    };
    
    // For demo purposes, mark as completed immediately
    // In production, integrate with payment processors
    donationData.status = 'completed';
    donationData.completed_at = new Date().toISOString();
    
    // Save donation
    const donationId = await db.saveDonation(donationData);
    
    // Update total
    await db.updateDonationTotal(amount);
    
    res.json({ 
      success: true, 
      donation_id: donationId,
      message: 'Donation processed successfully'
    });
  } catch (error) {
    console.error('Error processing donation:', error);
    res.status(500).json({ error: 'Failed to process donation' });
  }
});

// Update content
app.post('/api/admin/content', authenticateToken, async (req, res) => {
  try {
    const { section, content } = req.body;
    
    if (!section || !content) {
      return res.status(400).json({ error: 'Section and content required' });
    }
    
    await db.updateContent(section, content);
    res.json({ success: true, message: 'Content updated successfully' });
  } catch (error) {
    console.error('Error updating content:', error);
    res.status(500).json({ error: 'Failed to update content' });
  }
});

// Generate thank you letter
app.post('/api/admin/generate-letter', authenticateToken, async (req, res) => {
  try {
    const { donation_id } = req.body;
    
    if (!donation_id) {
      return res.status(400).json({ error: 'Donation ID required' });
    }
    
    const donation = await db.getDonationById(donation_id);
    if (!donation) {
      return res.status(404).json({ error: 'Donation not found' });
    }
    
    const letter = generateThankYouLetter(donation);
    res.json({ letter });
  } catch (error) {
    console.error('Error generating letter:', error);
    res.status(500).json({ error: 'Failed to generate letter' });
  }
});

// Add bulldog profile
app.post('/api/admin/bulldogs', authenticateToken, async (req, res) => {
  try {
    const { name, breed, age, description, medical_status, photo_url } = req.body;
    
    if (!name || !breed || !description) {
      return res.status(400).json({ error: 'Required fields missing' });
    }
    
    const bulldogId = await db.addBulldog({
      name, breed, age, description, medical_status, photo_url
    });
    
    res.json({ success: true, bulldog_id: bulldogId });
  } catch (error) {
    console.error('Error adding bulldog:', error);
    res.status(500).json({ error: 'Failed to add bulldog' });
  }
});

// Initialize default admin
app.post('/api/admin/init', async (req, res) => {
  try {
    const { username, password, name } = req.body;
    
    if (!username || !password || !name) {
      return res.status(400).json({ error: 'All fields required' });
    }
    
    // Check if admin exists
    const existingAdmin = await db.getAdminByUsername(username);
    if (existingAdmin) {
      return res.status(400).json({ error: 'Admin already exists' });
    }
    
    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);
    
    // Create admin
    await db.createAdmin({ username, password_hash: hashedPassword, name });
    
    res.json({ success: true, message: 'Admin created successfully' });
  } catch (error) {
    console.error('Error creating admin:', error);
    res.status(500).json({ error: 'Failed to create admin' });
  }
});

// Helper function to generate thank you letter
function generateThankYouLetter(donation) {
  const date = new Date().toLocaleDateString();
  
  return `
FANTASY BULLDOG KENNELS
123 Rescue Road
Second Chance City, State 12345

${date}

Dear ${donation.donor_name},

On behalf of everyone at Fantasy Bulldog Kennels, I want to express our heartfelt gratitude for your generous donation of $${donation.amount.toFixed(2)}.

Your support makes it possible for us to continue our mission of providing second chances to both formerly incarcerated individuals and rescued bulldogs. Your contribution will directly impact:

• Housing and support services for program participants
• Veterinary care and rehabilitation for rescued bulldogs  
• Job training and employment opportunities
• Community reintegration programs

Thanks to donors like you, we can continue breaking the cycle of recidivism while giving loving homes to bulldogs in need. Your generosity truly changes lives.

Fantasy Bulldog Kennels is a 501(c)(3) nonprofit organization. Your donation is tax-deductible to the extent allowed by law. Our tax identification number is [TAX-ID]. Please retain this letter for your tax records.

Thank you again for believing in our mission and supporting our work.

With sincere appreciation,

The Fantasy Bulldog Kennels Team

---
This letter serves as official acknowledgment of your donation made on ${new Date(donation.created_at).toLocaleDateString()}.
  `.trim();
}

// Start server
app.listen(PORT, () => {
  console.log(`Fantasy Bulldog Kennels server running on port ${PORT}`);
  console.log(`Admin setup: POST /api/admin/init to create first admin`);
});

module.exports = app;