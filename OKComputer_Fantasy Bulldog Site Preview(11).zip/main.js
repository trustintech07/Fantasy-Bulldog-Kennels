// Fantasy Bulldog Kennels - Main JavaScript
class FantasyBulldogKennels {
  constructor() {
    this.apiBase = window.location.origin;
    this.init();
  }

  init() {
    this.setupEventListeners();
    this.loadRealTimeData();
    this.recordPageView();
    this.initializeComponents();
  }

  setupEventListeners() {
    // Navigation
    document.addEventListener('DOMContentLoaded', () => {
      this.setupNavigation();
      this.setupDonationForm();
      this.setupContactForm();
      this.setupVolunteerForm();
      this.setupAdminLogin();
    });

    // Smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
      anchor.addEventListener('click', (e) => {
        e.preventDefault();
        const target = document.querySelector(anchor.getAttribute('href'));
        if (target) {
          target.scrollIntoView({ behavior: 'smooth' });
        }
      });
    });
  }

  setupNavigation() {
    const currentPage = window.location.pathname.split('/').pop() || 'index.html';
    const navLinks = document.querySelectorAll('nav a');
    
    navLinks.forEach(link => {
      const href = link.getAttribute('href');
      if (href === currentPage || (currentPage === '' && href === 'index.html')) {
        link.classList.add('active');
      }
    });
  }

  async loadRealTimeData() {
    try {
      const response = await fetch(`${this.apiBase}/api/stats`);
      const data = await response.json();
      
      this.updateCounters(data);
    } catch (error) {
      console.error('Error loading real-time data:', error);
    }
  }

  updateCounters(data) {
    const donationCounter = document.getElementById('donation-counter');
    const viewCounter = document.getElementById('view-counter');
    
    if (donationCounter) {
      this.animateCounter(donationCounter, data.total_donations || 0, '$');
    }
    
    if (viewCounter) {
      this.animateCounter(viewCounter, data.total_views || 0);
    }
  }

  animateCounter(element, targetValue, prefix = '') {
    const startValue = 0;
    const duration = 2000;
    const startTime = performance.now();

    const animate = (currentTime) => {
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / duration, 1);
      
      const currentValue = Math.floor(startValue + (targetValue - startValue) * progress);
      element.textContent = prefix + currentValue.toLocaleString();
      
      if (progress < 1) {
        requestAnimationFrame(animate);
      }
    };

    requestAnimationFrame(animate);
  }

  async recordPageView() {
    try {
      await fetch(`${this.apiBase}/api/view`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      });
    } catch (error) {
      console.error('Error recording page view:', error);
    }
  }

  setupDonationForm() {
    const donationForm = document.getElementById('donation-form');
    if (!donationForm) return;

    donationForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      
      const formData = new FormData(donationForm);
      const donationData = {
        amount: parseFloat(formData.get('amount')),
        donor_name: formData.get('donor_name'),
        donor_email: formData.get('donor_email'),
        method: formData.get('payment_method'),
        message: formData.get('message') || ''
      };

      if (!this.validateDonationForm(donationData)) {
        return;
      }

      try {
        const response = await fetch(`${this.apiBase}/api/donate`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(donationData)
        });

        const result = await response.json();

        if (result.success) {
          this.showSuccessMessage('Thank you for your donation! Your support makes our mission possible.');
          donationForm.reset();
          this.loadRealTimeData(); // Refresh counters
        } else {
          this.showErrorMessage(result.error || 'Donation processing failed. Please try again.');
        }
      } catch (error) {
        console.error('Error processing donation:', error);
        this.showErrorMessage('Network error. Please try again.');
      }
    });

    // Payment method selection
    const paymentMethods = document.querySelectorAll('input[name="payment_method"]');
    paymentMethods.forEach(method => {
      method.addEventListener('change', (e) => {
        this.showPaymentInstructions(e.target.value);
      });
    });
  }

  validateDonationForm(data) {
    if (!data.amount || data.amount <= 0) {
      this.showErrorMessage('Please enter a valid donation amount.');
      return false;
    }

    if (!data.donor_name || data.donor_name.trim().length < 2) {
      this.showErrorMessage('Please enter your name.');
      return false;
    }

    if (!data.donor_email || !this.isValidEmail(data.donor_email)) {
      this.showErrorMessage('Please enter a valid email address.');
      return false;
    }

    return true;
  }

  showPaymentInstructions(method) {
    const instructionsDiv = document.getElementById('payment-instructions');
    if (!instructionsDiv) return;

    let instructions = '';
    
    switch (method) {
      case 'stripe':
        instructions = 'You will be redirected to our secure payment processor to complete your donation.';
        break;
      case 'paypal':
        instructions = 'You will be redirected to PayPal to complete your donation securely.';
        break;
      case 'ach':
        instructions = 'Bank transfer instructions will be provided after submission. Please allow 3-5 business days for processing.';
        break;
      case 'crypto':
        instructions = 'Bitcoin (BTC): 1FantasyBulldogKennelx89xyz...<br>Ethereum (ETH): 0xFantasyBulldogKennel89xyz...';
        break;
      case 'property':
        instructions = 'Our development team will contact you within 24 hours to discuss your property donation.';
        break;
    }
    
    instructionsDiv.innerHTML = instructions;
    instructionsDiv.className = 'payment-instructions ' + method;
  }

  setupContactForm() {
    const contactForm = document.getElementById('contact-form');
    if (!contactForm) return;

    contactForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      
      const formData = new FormData(contactForm);
      const contactData = {
        name: formData.get('name'),
        email: formData.get('email'),
        subject: formData.get('subject'),
        message: formData.get('message')
      };

      if (!this.validateContactForm(contactData)) {
        return;
      }

      try {
        const response = await fetch(`${this.apiBase}/api/contact`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(contactData)
        });

        const result = await response.json();

        if (result.success) {
          this.showSuccessMessage('Thank you for contacting us! We will respond within 24 hours.');
          contactForm.reset();
        } else {
          this.showErrorMessage(result.error || 'Message sending failed. Please try again.');
        }
      } catch (error) {
        console.error('Error sending contact message:', error);
        this.showErrorMessage('Network error. Please try again.');
      }
    });
  }

  validateContactForm(data) {
    if (!data.name || data.name.trim().length < 2) {
      this.showErrorMessage('Please enter your name.');
      return false;
    }

    if (!data.email || !this.isValidEmail(data.email)) {
      this.showErrorMessage('Please enter a valid email address.');
      return false;
    }

    if (!data.message || data.message.trim().length < 10) {
      this.showErrorMessage('Please enter a message (minimum 10 characters).');
      return false;
    }

    return true;
  }

  setupVolunteerForm() {
    const volunteerForm = document.getElementById('volunteer-form');
    if (!volunteerForm) return;

    volunteerForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      
      const formData = new FormData(volunteerForm);
      const volunteerData = {
        name: formData.get('name'),
        email: formData.get('email'),
        phone: formData.get('phone'),
        experience: formData.get('experience'),
        availability: formData.get('availability'),
        interests: formData.get('interests')
      };

      if (!this.validateVolunteerForm(volunteerData)) {
        return;
      }

      try {
        const response = await fetch(`${this.apiBase}/api/volunteer`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(volunteerData)
        });

        const result = await response.json();

        if (result.success) {
          this.showSuccessMessage('Thank you for your interest in volunteering! We will contact you within 48 hours.');
          volunteerForm.reset();
        } else {
          this.showErrorMessage(result.error || 'Application submission failed. Please try again.');
        }
      } catch (error) {
        console.error('Error submitting volunteer application:', error);
        this.showErrorMessage('Network error. Please try again.');
      }
    });
  }

  validateVolunteerForm(data) {
    if (!data.name || data.name.trim().length < 2) {
      this.showErrorMessage('Please enter your name.');
      return false;
    }

    if (!data.email || !this.isValidEmail(data.email)) {
      this.showErrorMessage('Please enter a valid email address.');
      return false;
    }

    if (!data.phone || !this.isValidPhone(data.phone)) {
      this.showErrorMessage('Please enter a valid phone number.');
      return false;
    }

    return true;
  }

  setupAdminLogin() {
    const adminLoginForm = document.getElementById('admin-login-form');
    if (!adminLoginForm) return;

    adminLoginForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      
      const formData = new FormData(adminLoginForm);
      const loginData = {
        username: formData.get('username'),
        password: formData.get('password')
      };

      try {
        const response = await fetch(`${this.apiBase}/api/admin/login`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(loginData)
        });

        const result = await response.json();

        if (response.ok) {
          // Store token and redirect to admin dashboard
          localStorage.setItem('admin_token', result.token);
          localStorage.setItem('admin_user', JSON.stringify(result.user));
          window.location.href = 'admin.html';
        } else {
          this.showErrorMessage(result.error || 'Login failed. Please try again.');
        }
      } catch (error) {
        console.error('Error during admin login:', error);
        this.showErrorMessage('Network error. Please try again.');
      }
    });
  }

  initializeComponents() {
    // Initialize any additional components
    this.setupImageGalleries();
    this.setupScrollAnimations();
    this.setupMobileMenu();
  }

  setupImageGalleries() {
    const galleries = document.querySelectorAll('.image-gallery');
    galleries.forEach(gallery => {
      const images = gallery.querySelectorAll('img');
      images.forEach(img => {
        img.addEventListener('click', () => {
          this.openImageModal(img.src, img.alt);
        });
      });
    });
  }

  openImageModal(src, alt) {
    const modal = document.createElement('div');
    modal.className = 'image-modal';
    modal.innerHTML = `
      <div class="modal-overlay" onclick="this.parentElement.remove()">
        <div class="modal-content" onclick="event.stopPropagation()">
          <img src="${src}" alt="${alt}">
          <button class="modal-close" onclick="this.closest('.image-modal').remove()">&times;</button>
        </div>
      </div>
    `;
    
    document.body.appendChild(modal);
  }

  setupScrollAnimations() {
    const observerOptions = {
      threshold: 0.1,
      rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('animate-in');
        }
      });
    }, observerOptions);

    // Observe elements with animation classes
    document.querySelectorAll('.animate-on-scroll').forEach(el => {
      observer.observe(el);
    });
  }

  setupMobileMenu() {
    const menuToggle = document.getElementById('mobile-menu-toggle');
    const mobileMenu = document.getElementById('mobile-menu');
    
    if (menuToggle && mobileMenu) {
      menuToggle.addEventListener('click', () => {
        mobileMenu.classList.toggle('active');
        menuToggle.classList.toggle('active');
      });
    }
  }

  // Utility functions
  isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  isValidPhone(phone) {
    const phoneRegex = /^[\+]?[1-9][\d]{0,15}$/;
    return phoneRegex.test(phone.replace(/[\s\-\(\)]/g, ''));
  }

  showSuccessMessage(message) {
    this.showMessage(message, 'success');
  }

  showErrorMessage(message) {
    this.showMessage(message, 'error');
  }

  showMessage(message, type) {
    const messageDiv = document.createElement('div');
    messageDiv.className = `message message-${type}`;
    messageDiv.textContent = message;
    
    // Style the message
    messageDiv.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      padding: 1rem 1.5rem;
      border-radius: 8px;
      color: white;
      font-weight: 500;
      z-index: 10000;
      max-width: 400px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.15);
      background: ${type === 'success' ? '#059669' : '#dc2626'};
    `;
    
    document.body.appendChild(messageDiv);
    
    // Animate in
    setTimeout(() => {
      messageDiv.style.transform = 'translateX(0)';
      messageDiv.style.opacity = '1';
    }, 100);
    
    // Remove after 5 seconds
    setTimeout(() => {
      messageDiv.style.transform = 'translateX(100%)';
      messageDiv.style.opacity = '0';
      setTimeout(() => messageDiv.remove(), 300);
    }, 5000);
  }

  // Admin dashboard functions
  async loadAdminDashboard() {
    const token = localStorage.getItem('admin_token');
    if (!token) {
      window.location.href = 'login.html';
      return;
    }

    try {
      const response = await fetch(`${this.apiBase}/api/admin/dashboard`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });

      if (response.ok) {
        const data = await response.json();
        this.updateDashboard(data);
      } else if (response.status === 401) {
        localStorage.removeItem('admin_token');
        window.location.href = 'login.html';
      }
    } catch (error) {
      console.error('Error loading dashboard:', error);
    }
  }

  updateDashboard(data) {
    // Update dashboard statistics
    const elements = {
      'total-donations': data.donation_count,
      'total-amount': `$${data.total_donated.toFixed(2)}`,
      'total-views': data.total_views,
      'total-bulldogs': data.total_bulldogs,
      'available-bulldogs': data.available_bulldogs,
      'pending-volunteers': data.pending_volunteers,
      'new-messages': data.new_messages
    };

    Object.entries(elements).forEach(([id, value]) => {
      const element = document.getElementById(id);
      if (element) {
        element.textContent = value;
      }
    });
  }
}

// Initialize the application
const app = new FantasyBulldogKennels();

// Global functions for HTML onclick handlers
window.fantasyBulldogApp = app;